import {APP} from '../config.js';
export const DEFAULT_STATE={version:4,onboard:false,answers:{goal:['hypertrophy'],level:'beginner',equipment:['none'],frequency:'3',duration:'20–35 min',focus:['body']},xp:0,streak:0,lastWorkout:null,workouts:0,minutes:0,sets:0,completedSplits:[],history:[],progress:{},currentSplit:'A'};
const clone=x=>JSON.parse(JSON.stringify(x));
export function loadState(){try{const raw=JSON.parse(localStorage.getItem(APP.storageKey)||'null');if(!raw)return clone(DEFAULT_STATE);return normalize({...clone(DEFAULT_STATE),...raw,answers:{...DEFAULT_STATE.answers,...(raw.answers||{})}})}catch{return clone(DEFAULT_STATE)}}
function normalize(s){for(const k of ['goal','equipment','focus'])if(!Array.isArray(s.answers[k]))s.answers[k]=[s.answers[k]];s.answers.goal=s.answers.goal?.length?s.answers.goal:['hypertrophy'];s.answers.equipment=s.answers.equipment?.length?s.answers.equipment:['none'];s.answers.focus=s.answers.focus?.length?s.answers.focus:['body'];s.completedSplits=Array.isArray(s.completedSplits)?s.completedSplits:[];s.history=Array.isArray(s.history)?s.history:[];return s}
export function saveState(state){localStorage.setItem(APP.storageKey,JSON.stringify(state))}
export function resetState(){localStorage.removeItem(APP.storageKey)}
export function exportState(state){const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='home-training-progresso.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),500)}
